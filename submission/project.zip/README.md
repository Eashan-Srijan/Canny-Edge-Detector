# Canny Edge Detector from Scratch
